ActionState.seed_once(:i18n_name) do |s|
  s.i18n_name = "open"
end

ActionState.seed_once(:i18n_name) do |s|
  s.i18n_name = "closed"
end
