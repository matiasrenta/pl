RiskProbability.seed_once(:i18n_name) do |s|
  s.i18n_name = "low"
end

RiskProbability.seed_once(:i18n_name) do |s|
  s.i18n_name = "medium"
end

RiskProbability.seed_once(:i18n_name) do |s|
  s.i18n_name = "high"
end

RiskProbability.seed_once(:i18n_name) do |s|
  s.i18n_name = "very_high"
end
