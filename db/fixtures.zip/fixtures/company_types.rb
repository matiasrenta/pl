CompanyType.seed_once(:i18n_name) do |s|
  s.i18n_name = "customer"
end

CompanyType.seed_once(:i18n_name) do |s|
  s.i18n_name = "provider"
end

CompanyType.seed_once(:i18n_name) do |s|
  s.i18n_name = "partner"
end

CompanyType.seed_once(:i18n_name) do |s|
  s.i18n_name = "other"
end
