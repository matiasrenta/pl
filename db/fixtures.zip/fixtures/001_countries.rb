Country.seed_once(:name) do |s|
  s.name = "México"
  s.state_id = State.find_by_i18n_name("active")
end