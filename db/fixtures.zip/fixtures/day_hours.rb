DayHour.seed_once(:hours) do |s|
  s.hours = 8
end
