ProblemPriority.seed_once(:i18n_name) do |s|
  s.i18n_name = "low"
end

ProblemPriority.seed_once(:i18n_name) do |s|
  s.i18n_name = "medium"
end

ProblemPriority.seed_once(:i18n_name) do |s|
  s.i18n_name = "high"
end