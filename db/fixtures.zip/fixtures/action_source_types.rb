ActionSourceType.seed_once(:i18n_name) do |s|
  s.i18n_name = "problem"
end

ActionSourceType.seed_once(:i18n_name) do |s|
  s.i18n_name = "report"
end

ActionSourceType.seed_once(:i18n_name) do |s|
  s.i18n_name = "risk"
end

ActionSourceType.seed_once(:i18n_name) do |s|
  s.i18n_name = "decision"
end
