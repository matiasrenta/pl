User.seed_once(:email) do |s|
  s.email = "admin@mail.com"
  s.encrypted_password = "$2a$10$Aab0ZfDadBqK7hpn8C9vKu.5AF65OwtQ9GDvoUlLEzynbJLEIN5ha"
  s.role_id = Role.admin.id
  s.name = "Administrador"
  s.last_name = "Net"
end

#User.seed_once(:email) do |s|
#  s.email = "superuser@mail.com"
#  s.encrypted_password = "$2a$10$Aab0ZfDadBqK7hpn8C9vKu.5AF65OwtQ9GDvoUlLEzynbJLEIN5ha"
#  s.role_id = Role.superuser.id
#  s.name = "Superuser"
#  s.last_name = "Boss"
#end

