TaskType.seed_once(:i18n_name) do |s|
  s.i18n_name = "planned"
end

TaskType.seed_once(:i18n_name) do |s|
  s.i18n_name = "rework"
end

TaskType.seed_once(:i18n_name) do |s|
  s.i18n_name = "change"
end