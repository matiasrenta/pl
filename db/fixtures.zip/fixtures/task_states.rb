TaskState.seed_once(:i18n_name) do |s|
  s.i18n_name = "assigned"
end

TaskState.seed_once(:i18n_name) do |s|
  s.i18n_name = "in_progress"
end

TaskState.seed_once(:i18n_name) do |s|
  s.i18n_name = "closed"
end

TaskState.seed_once(:i18n_name) do |s|
  s.i18n_name = "canceled"
end
