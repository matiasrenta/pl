RegionState.seed_once(:name) do |s|
  s.name = "DF"
  s.country_id = Country.find_by_name("México").id
  s.state_id = State.find_by_i18n_name("active")
end

RegionState.seed_once(:name) do |s|
  s.name = "Jalisco"
  s.country_id = Country.find_by_name("México").id
  s.state_id = State.find_by_i18n_name("active")
end

RegionState.seed_once(:name) do |s|
  s.name = "Sinaloa"
  s.country_id = Country.find_by_name("México").id
  s.state_id = State.find_by_i18n_name("active")
end