DayOff.seed_once(:wday, :company) do |s|
  s.wday = 0
  s.company = true
  s.off = true
end

DayOff.seed_once(:wday, :company) do |s|
  s.wday = 1
  s.company = true
  s.off = false
end

DayOff.seed_once(:wday, :company) do |s|
  s.wday = 2
  s.company = true
  s.off = false
end

DayOff.seed_once(:wday, :company) do |s|
  s.wday = 3
  s.company = true
  s.off = false
end

DayOff.seed_once(:wday, :company) do |s|
  s.wday = 4
  s.company = true
  s.off = false
end

DayOff.seed_once(:wday, :company) do |s|
  s.wday = 5
  s.company = true
  s.off = false
end

DayOff.seed_once(:wday, :company) do |s|
  s.wday = 6
  s.company = true
  s.off = true
end

