ProjectState.seed_once(:i18n_name) do |s|
  s.i18n_name = "created"
end

ProjectState.seed_once(:i18n_name) do |s|
  s.i18n_name = "in_progress"
end

ProjectState.seed_once(:i18n_name) do |s|
  s.i18n_name = "closed"
end

ProjectState.seed_once(:i18n_name) do |s|
  s.i18n_name = "suspended"
end

ProjectState.seed_once(:i18n_name) do |s|
  s.i18n_name = "canceled"
end

