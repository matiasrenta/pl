RiskExposition.seed_once(:i18n_name) do |s|
  s.i18n_name = "low"
  s.color = "green"
end

RiskExposition.seed_once(:i18n_name) do |s|
  s.i18n_name = "medium"
  s.color = "yellow"
end

RiskExposition.seed_once(:i18n_name) do |s|
  s.i18n_name = "high"
  s.color = "orange"
end

RiskExposition.seed_once(:i18n_name) do |s|
  s.i18n_name = "very_high"
  s.color = "red"
end
