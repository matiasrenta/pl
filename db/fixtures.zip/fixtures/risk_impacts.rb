RiskImpact.seed_once(:i18n_name) do |s|
  s.i18n_name = "low"
end

RiskImpact.seed_once(:i18n_name) do |s|
  s.i18n_name = "medium"
end

RiskImpact.seed_once(:i18n_name) do |s|
  s.i18n_name = "high"
end

RiskImpact.seed_once(:i18n_name) do |s|
  s.i18n_name = "very_high"
end
