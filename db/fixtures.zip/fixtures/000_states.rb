State.seed_once(:i18n_name) do |s|
  s.i18n_name = "active"
end

State.seed_once(:i18n_name) do |s|
  s.i18n_name = "inactive"
end